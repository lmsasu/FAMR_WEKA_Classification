package ro.unitbv.pythia;

/**
 * Global settings
 * @author Lucian Sasu
 */
public class Settings {
	public static boolean debugMode = true;
}
