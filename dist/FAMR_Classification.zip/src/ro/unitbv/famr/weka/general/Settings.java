/**
 * 
 */
package ro.unitbv.famr.weka.general;

/**
 * @author Lucian
 *
 */
public class Settings {
	private Settings() {
		
	}
	
	public static String logPath = "d:\\temp\\FAMR_wekalog.txt";
}
